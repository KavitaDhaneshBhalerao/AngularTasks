import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ProductListsComponent } from './components/product-lists/product-lists.component';
import { CartComponent } from './components/cart/cart.component';
import { HeaderComponent } from './components/header/header.component';
import { IndexComponent } from './components/index/index.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, IndexComponent,ProductListsComponent,CartComponent,HeaderComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'codzenTask';
}
