import { Component } from '@angular/core';
import { Router, RouterLink, RouterModule } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { ProductListsComponent } from "../product-lists/product-lists.component";

@Component({
  selector: 'app-index',
  standalone: true,
  imports: [RouterModule, RouterLink, HeaderComponent, ProductListsComponent],
  templateUrl: './index.component.html',
  styleUrl: './index.component.css'
})
export class IndexComponent {

}
