import { Component, inject } from '@angular/core';
import { CartService } from '../../services/cart.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-product-lists',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './product-lists.component.html',
  styleUrl: './product-lists.component.css'
})
export class ProductListsComponent {

  cartService = inject(CartService)

  products:any[]=[
    {id:1,  name:"Focus Paper Refill",price:821,img:"https://tailwindui.com/img/ecommerce-images/category-page-04-image-card-03.jpg"},
    {id:2,  name:"Nomad Tumbler",price:350,img:"https://tailwindui.com/img/ecommerce-images/category-page-04-image-card-02.jpg"},
    { id:3, name:"Machined Mechanical Pencil",price:421,img:"https://tailwindui.com/img/ecommerce-images/category-page-04-image-card-04.jpg"},
    {id:4, name:"Earthen Bottle",price:480,img:"https://tailwindui.com/img/ecommerce-images/category-page-04-image-card-01.jpg"}
  ];

  // addToCart(product:any){
  //   this.cartService.addToCart(product)
  // }/

  addToCart(product: any, event: Event): void {
    event.stopPropagation();
    event.preventDefault(); 
    this.cartService.addToCart(product);
  }

}
