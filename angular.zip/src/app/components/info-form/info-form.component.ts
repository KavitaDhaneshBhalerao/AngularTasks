import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-info-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './info-form.component.html',
  styleUrls: ['./info-form.component.css']
})
export class InfoFormComponent {
  infoForm: FormGroup;

  constructor(private fb: FormBuilder) {
  
    this.infoForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      mobileNo: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      address: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      age: ['', [Validators.required, Validators.min(1)]],
      dob: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.infoForm.valid) {

      console.log(this.infoForm.value);
      console.log(this.infoForm.value.firstName);
      console.log(this.infoForm.value.age);

      this.infoForm.reset();
    } else {
      
      console.error('Form is invalid');
    }
  }
}
