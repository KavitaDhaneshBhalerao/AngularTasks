import { Component, inject } from '@angular/core';
import { ProductListsComponent } from '../product-lists/product-lists.component';
import { CommonModule } from '@angular/common';
import { CartService } from '../../services/cart.service';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [ProductListsComponent,CommonModule],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css'
})
export class CartComponent {

  cartService=inject(CartService);

  deleteToCart(item:any){
    this.cartService.delete(item);
  }

}
