import { Routes } from '@angular/router';
import { HeaderComponent } from './components/header/header.component';
import { ProductListsComponent } from './components/product-lists/product-lists.component';
import { CartComponent } from './components/cart/cart.component';
import { InfoFormComponent } from './components/info-form/info-form.component';

export const routes: Routes = [
{path:'',redirectTo:'/products',pathMatch:'full'},
    {path:'head',component:HeaderComponent},
    {path:'products', component:ProductListsComponent},
    {path:'cart',component:CartComponent},
    {path:'form',component:InfoFormComponent}
];
